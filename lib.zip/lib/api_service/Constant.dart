


class Constant {

  static const String baseUrl = 'http://attendance.mrshakil.com/';
  static const String loginUrl = 'http://attendance.mrshakil.com/api/login/';
  static const String myAttendanceUrl = 'http://attendance.mrshakil.com/api/my-attendance/';
  static const String submitAttendance = 'http://attendance.mrshakil.com/api/submit-attendance/';
  static const String workingSummary = 'http://attendance.mrshakil.com/api/employee-working-summary/';
  static const String userInfoPref = 'UserInfo';
  static const String userInfo = 'UserInfo';


}