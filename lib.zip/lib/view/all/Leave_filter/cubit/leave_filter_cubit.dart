import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'leave_filter_state.dart';

class LeaveFilterCubit extends Cubit<LeaveFilterState> {
  LeaveFilterCubit() : super(LeaveFilterInitial());
}
