part of 'leave_filter_cubit.dart';

@immutable
sealed class LeaveFilterState {}

final class LeaveFilterInitial extends LeaveFilterState {}
