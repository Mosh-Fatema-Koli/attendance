import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../common_controller/MiscController.dart';
import 'wfh_Repository.dart';
import 'wfh_history_state.dart';

class WFHHistoryCubit extends Cubit<WFHHistoryState> {
  WFHHistoryCubit() : super( WFHHistoryInitial());

  final _repository = WFHRepository();
  final _miscController = MiscController();

  void loadData({BuildContext? context}) {
    if (context != null) {
      _miscController.showProgressDialog(context: context);
    }

    _repository.fetchData(
      onComplete: (isSuccess, message, dataList) {
        if (context != null) {
          Navigator.pop(context);
        }
        emit(WFHHistoryLoadedState(
          success: isSuccess,
          message: message,
          listOfData: dataList,
        ));
      },
    );
  }

  void filter({BuildContext? context, required String date}) {
    if (context != null) {
      _miscController.showProgressDialog(context: context);
    }

    _repository.filterByDate(
      datalist: state.listOfData,
      date: date,
      onComplete: (isSuccess, message, dataList) {
        if (context != null) {
          Navigator.pop(context);
        }
        emit(WFHHistoryLoadedState(
          success: isSuccess,
          message: message,
          listOfData: dataList,
        ));
      },
    );
  }
}
