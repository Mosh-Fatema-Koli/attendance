part of 'wfhentry_cubit.dart';

@immutable
sealed class WfhentryState {}

final class WfhentryInitial extends WfhentryState {}
