import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'wfhentry_state.dart';

class WfhentryCubit extends Cubit<WfhentryState> {
  WfhentryCubit() : super(WfhentryInitial());
}
