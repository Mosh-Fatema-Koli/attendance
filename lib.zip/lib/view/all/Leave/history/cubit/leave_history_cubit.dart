

import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../common_controller/MiscController.dart';
import 'leave_Repository.dart';
import 'leave_history_state.dart';

class LeaveHistoryCubit extends Cubit<LeaveHistoryState> {
  LeaveHistoryCubit() : super( LeaveHistoryInitial());

  final _repository = LeaveRepository();
  final _miscController = MiscController();

  void loadData({BuildContext? context}) {
    if (context != null) {
      _miscController.showProgressDialog(context: context);
    }

    _repository.fetchData(
      onComplete: (isSuccess, message, dataList) {
        if (context != null) {
          Navigator.pop(context);
        }

        emit(LeaveHistoryLoadedState(
          success: isSuccess,
          message: message,
          listOfData: dataList,
        ));
      },
    );
  }

  void filter({BuildContext? context, required String date}) {
    if (context != null) {
      _miscController.showProgressDialog(context: context);
    }

    _repository.filterByDate(
      datalist: state.listOfData,
      date: date,
      onComplete: (isSuccess, message, dataList) {
        if (context != null) {
          Navigator.pop(context);
        }

        emit(LeaveHistoryLoadedState(
          success: isSuccess,
          message: message,
          listOfData: dataList,
        ));
      },
    );
  }

  //
  // Future<void> delete({
  //   required BuildContext context,
  //   required Function(bool isSuccess, String message) onComplete,
  //   required String image,
  //   required int attendance_type,
  // }) async {
  //   // ✅ Get MAC Address
  //   String? macAddress = await getMacAddress();
  //
  //   _miscController.showAlertDialog(
  //     context: context,
  //     cancelable: false,
  //     title: "Do you want to send?",
  //     subTitle: "MAC Address: $macAddress ,\nattendance_type: ${attendance_type == 0 ? "Entry" : "Exit"}",
  //     okText: "Send",
  //     okPressed: () async {
  //       _miscController.navigateBack(context: context);
  //       _miscController.showProgressDialog(context: context);
  //
  //       print("MAC Address: $macAddress");
  //
  //       await _miscController.checkInternet().then((value) async {
  //         if (!value.contains('ignore')) {
  //           try {
  //             // ✅ Validate File Exists
  //             File imageFile = File(image);
  //             if (!imageFile.existsSync()) {
  //               print("Error: Image file not found at path: $image");
  //               emit(CheckInError("Image file not found"));
  //               return;
  //             }
  //
  //             // ✅ Convert Image to MultipartFile
  //             MultipartFile multipartFile = await MultipartFile.fromFile(
  //               imageFile.path,
  //               filename: "attendance_image.jpg",
  //             );
  //
  //             // ✅ Wrap in FormData
  //             FormData formData = FormData.fromMap({
  //               "image": multipartFile,
  //               "attendance_type": attendance_type == 0 ? "entry" : "exit",
  //               "mac_address": macAddress,
  //             });
  //
  //             // ✅ Send API Request
  //             var apiResponse = await api.postData(
  //               endpoint: "/submit-attendance/",
  //               token: AppCache().userInfo?.token.toString(),
  //               data: formData, // ✅ Pass FormData directly
  //             );
  //
  //             var response = jsonDecode(apiResponse);
  //             var success = response['Success'];
  //             var message = response['Packet']['error'];
  //
  //             _miscController.navigateBack(context: context);
  //
  //             if (success) {
  //               print("API Response: $response");
  //
  //               onComplete(true, '$message');
  //               emit(CheckInLoaded(success: true, message: message));
  //             } else {
  //               onComplete(false, 'Upload Failed: $message');
  //               emit(CheckInLoaded(success: false, message: "Something went wrong"));
  //             }
  //           } catch (e) {
  //             print("Upload Error: $e");
  //             onComplete(false, 'Upload Error: ${e.toString()}');
  //             emit(CheckInError("Upload failed: ${e.toString()}"));
  //           }
  //         } else {
  //           onComplete(false, "Internet Error!\nYou are offline, Please check your internet connection.");
  //           emit(CheckInLoaded(success: false, message: "Something went wrong"));
  //         }
  //       });
  //     },
  //     cancelText: "No",
  //     cancelPressed: () {
  //       _miscController.navigateBack(context: context);
  //     },
  //   );
  // }
}
