class MenuModel {
  String name;
  String image;

  MenuModel({required this.name, required this.image});


}